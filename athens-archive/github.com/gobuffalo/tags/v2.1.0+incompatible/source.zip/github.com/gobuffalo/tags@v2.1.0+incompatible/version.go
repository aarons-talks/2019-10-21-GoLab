package tags

//Version holds current source version number
const Version = "v2.1.0"
