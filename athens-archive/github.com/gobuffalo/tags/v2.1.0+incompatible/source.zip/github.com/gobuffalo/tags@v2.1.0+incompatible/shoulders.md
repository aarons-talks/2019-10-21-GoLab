# github.com/gobuffalo/tags Stands on the Shoulders of Giants

github.com/gobuffalo/tags does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/fatih/structs](https://godoc.org/github.com/fatih/structs)

* [github.com/gobuffalo/flect](https://godoc.org/github.com/gobuffalo/flect)

* [github.com/gobuffalo/uuid](https://godoc.org/github.com/gobuffalo/uuid)

* [github.com/gobuffalo/validate](https://godoc.org/github.com/gobuffalo/validate)

* [github.com/gofrs/uuid](https://godoc.org/github.com/gofrs/uuid)

* [github.com/onsi/ginkgo](https://godoc.org/github.com/onsi/ginkgo)

* [github.com/onsi/gomega](https://godoc.org/github.com/onsi/gomega)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/serenize/snaker](https://godoc.org/github.com/serenize/snaker)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)
