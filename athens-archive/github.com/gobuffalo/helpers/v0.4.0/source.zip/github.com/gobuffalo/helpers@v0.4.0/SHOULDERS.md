# github.com/gobuffalo/helpers Stands on the Shoulders of Giants

github.com/gobuffalo/helpers does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants, this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/fatih/structs](https://godoc.org/github.com/fatih/structs)

* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/gobuffalo/flect](https://godoc.org/github.com/gobuffalo/flect)

* [github.com/gobuffalo/github_flavored_markdown](https://godoc.org/github.com/gobuffalo/github_flavored_markdown)

* [github.com/gobuffalo/tags](https://godoc.org/github.com/gobuffalo/tags)

* [github.com/gobuffalo/uuid](https://godoc.org/github.com/gobuffalo/uuid)

* [github.com/gobuffalo/validate](https://godoc.org/github.com/gobuffalo/validate)

* [github.com/gofrs/uuid](https://godoc.org/github.com/gofrs/uuid)

* [github.com/golang/protobuf](https://godoc.org/github.com/golang/protobuf)

* [github.com/onsi/ginkgo](https://godoc.org/github.com/onsi/ginkgo)

* [github.com/onsi/gomega](https://godoc.org/github.com/onsi/gomega)

* [github.com/pkg/errors](https://godoc.org/github.com/pkg/errors)

* [github.com/rogpeppe/go-internal](https://godoc.org/github.com/rogpeppe/go-internal)

* [github.com/serenize/snaker](https://godoc.org/github.com/serenize/snaker)

* [github.com/stretchr/testify](https://godoc.org/github.com/stretchr/testify)

* [golang.org/x/net](https://godoc.org/golang.org/x/net)

* [golang.org/x/sys](https://godoc.org/golang.org/x/sys)

* [golang.org/x/text](https://godoc.org/golang.org/x/text)
